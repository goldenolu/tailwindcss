import random

# --- CORE GAME CONSTANTS ---
MAX_HEALTH = 100
MAX_ASSURANCE = 100
ASSURANCE_GAIN_PARRY = 25  # High reward for high skill
ASSURANCE_GAIN_KILL = 10
ASSURANCE_DURATION = 5.0 
DAMAGE_REDUCTION_AURA = 0.6  # 60% damage reduction when Assured


# --- CHARACTER CLASS ---
class Olujoker:
    def __init__(self, name="Olujoker"):
        self.name = name
        self.health = MAX_HEALTH
        self.assurance_meter = 0
        self.is_assured = False
        self.assurance_timer = 0.0
        self.attire_name = "Prototype Suit"
        self.is_alive = True

    def equip_vanguard_attire(self):
        """The reward for the Prologue: Equipping the signature Black & Gold suit."""
        self.attire_name = "Vanguard Protocol Attire (Black & Gold)"
        print(f"\n[{self.name}]: Equips the {self.attire_name}! Self-belief level MAX.")

    def gain_assurance(self, amount):
        """Increases the Aura of Assurance meter based on skilled actions."""
        if not self.is_assured:
            self.assurance_meter = min(self.assurance_meter + amount, MAX_ASSURANCE)
            print(f"[{self.name}]: Assurance Gained ({self.assurance_meter}/{MAX_ASSURANCE})")
        
        if self.assurance_meter == MAX_ASSURANCE:
            self.activate_assurance()

    def activate_assurance(self):
        """Olujoker activates his overwhelming confidence."""
        if self.assurance_meter == MAX_ASSURANCE and not self.is_assured:
            self.is_assured = True
            self.assurance_meter = 0 
            self.assurance_timer = ASSURANCE_DURATION
            print(f"\n<<< {self.name} ACTIVATES THE AURA OF ASSURANCE! 'This is already over.' >>>")
            print("  --- Perfect Accuracy & High Damage Resistance Active ---")

    def update_assurance_timer(self, delta_time):
        """Counts down the duration of the Aura."""
        if self.is_assured:
            self.assurance_timer -= delta_time
            if self.assurance_timer <= 0:
                self.is_assured = False
                print(f"[{self.name}]: Aura fades. Returning to standard parameters.")

    def take_damage(self, source, base_amount):
        """Calculates damage taken, reduced by Assurance if active."""
        damage = base_amount
        
        if self.is_assured:
            damage *= (1 - DAMAGE_REDUCTION_AURA)
            print(f"[{self.name}]: (Aura Active) Shrugs off heavy hit from {source}. Damage reduced to {damage:.1f}")
        else:
            print(f"[{self.name}]: Hit by {source}. Taking {damage} damage.")

        self.health -= damage
        if self.health <= 0 and self.is_alive:
            self.is_alive = False
            print(f"\n[SYSTEM]: {self.name} defeated. 'An anomaly. Correcting parameters.'")


# --- COMBAT FUNCTIONS ---
def handle_parry_attempt(olujoker):
    """Simulates checking for a successful Resonance Shield parry."""
    if random.random() < 0.7: 
        print("\n[COMBAT]: PERFECT PARRY! Resonance Shield reflects the laser.")
        olujoker.gain_assurance(ASSURANCE_GAIN_PARRY)
        return True
    else:
        print("\n[COMBAT]: Parry failed. Taking full damage.")
        olujoker.take_damage("Laser Bolt", 25)
        return False


# --- GAME SIMULATION EXAMPLE ---
if __name__ == "__main__":
    olujoker = Olujoker()
    olujoker.equip_vanguard_attire()
    
    # Olujoker needs 4 successful parries (4 x 25 = 100) to activate the Aura
    for i in range(1, 5):
        print(f"\n--- PARRY ATTEMPT {i} ---")
        handle_parry_attempt(olujoker)
        if olujoker.is_assured:
            break

    # Olujoker is now Assured and takes reduced damage
    print("\n--- TEST DAMAGE WHILE ASSURED ---")
    olujoker.take_damage("Heavy Explosion", 70) 
    
    # Simulate time passing and Aura fading
    olujoker.update_assurance_timer(5.0) 
    
    print("\n--- FINAL STATUS ---")
    print(f"Health: {olujoker.health:.1f}/{MAX_HEALTH}")
    print(f"Attire: {olujoker.attire_name}")


# Language:Python 
# ProjectType:0 
# Copy the full code and open the PyCoder APP to run it. 
# PyCoder APP download link：https://play.google.com/store/apps/details?id=com.ikou.pycoding 